import axiosClient from "./axiosClient"
import qs from 'qs';

const sensorAPI = {

    // [GET] agent/_id_agent/warehouse/:id_warehouse/sensor/get_all
    // [POST] agent/:id_agent/warehouse/:id_warehouse/sensor/:id_sensor/assign
    // [POST] agent/:id_agent/warehouse/:id_warehouse/sensor/:id_sensor/update_posotion
    // [DELETE] agent/:id_agent/warehouse/:id_warehouse/sensor/:id_sensor/remove

}

export default sensorAPI