import axiosClient from "./axiosClient"
import qs from 'qs';

const warehouseAPI = {

    // [GET] agent/:id_agent/warehouse/get_all
    // [GET] agent/:id_agent/warehouse/add
    // [POST] agent/:id_agent/warehouse/:id_warehouse/update
    // [POST] agent/:id_agent/warehouse/:id_warehouse/import
    // [DELETE] agent/:id_agent/warehouse/:id_warehouse/export
    // [DELETE] agent/:id_agent/warehouse/:id_warehouse/delete

}

export default warehouseAPI