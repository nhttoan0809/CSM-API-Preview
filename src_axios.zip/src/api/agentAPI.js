import axiosClient from "./axiosClient"
import qs from 'qs';

const agentAPI = {

    // [GET] agent/add
    // [POST] agent/:id_agent/update
    // [DELETE] agent/:id_agent/delete

}

export default agentAPI