import axiosClient from "./axiosClient"
import qs from 'qs';

const stationAPI = {

    // [GET] agent/_id_agent/warehouse/:id_warehouse/station/connect
    // [DELETE] agent/_id_agent/warehouse/:id_warehouse/station/:id_station/disconnect

}

export default stationAPI