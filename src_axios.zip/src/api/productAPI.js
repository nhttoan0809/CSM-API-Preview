import axiosClient from "./axiosClient"
import qs from 'qs';

const productAPI = {

    // [GET] agent/:id_agent/warehouse/:id_warehouse/prodcut/get_all
    // [POST] agent/:id_agent/warehouse/:id_warehouse/product/:id_product/add_to_pallet
    // [POST] agent/:id_agent/warehouse/:id_warehouse/product/:id_product/remove_from_pallet
    // [POST] agent/:id_agent/warehouse/:id_warehouse/product/:id_product/update_information
    // [POST] agent/:id_agent/warehouse/:id_warehouse/product/:id_product/update_position    

}

export default productAPI