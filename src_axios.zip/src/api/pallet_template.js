import axiosClient from "./axiosClient"
import qs from 'qs';

const pallet_template = {
    
    // [GET] pallet_template/get_all
    
}

export default pallet_template